<noscript>
    <div style="background-color:#F90; border:#666; font-size:22px; padding:15px; text-align:center">
        <strong>Please enable your javascript to get better performance.</strong>
    </div>
</noscript>

<div class="modal fade" id="myModal_autocomplete" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <i class="fa fa-times modal_box_class" data-dismiss="modal" style="float: right"></i>

                
                <h4 class="modal-title"></h4>
            </div>
            <div class="modal-body">
            </div>
        </div>
    </div>
</div>


<div class="clearfix"></div>

